@echo off
setlocal
echo ================================================================
echo CORTEX LOCKDOWN - DESKTOP CLIENT UNINSTALLER
echo Target: Windows 10/11 x64 Institutional Baseline
echo ================================================================

echo [INFO] Removing custom protocol: cortex-lockdown://
reg delete "HKCU\Software\Classes\cortex-lockdown" /f >nul 2>&1

set "TARGET_DIR=%LOCALAPPDATA%\CortexLockdown"
set "START_MENU_LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Cortex Lockdown.lnk"

if exist "%START_MENU_LNK%" (
    echo [INFO] Removing Start Menu shortcut...
    del /F /Q "%START_MENU_LNK%" >nul 2>&1
)

if exist "%TARGET_DIR%\CortexLockdown.exe" (
    echo [INFO] Removing executable: %TARGET_DIR%\CortexLockdown.exe
    del /F /Q "%TARGET_DIR%\CortexLockdown.exe" >nul 2>&1
)

:: Ensure uninstallation preserves student examination data by default
if exist "%TARGET_DIR%\SecureStorage" (
    echo [INFO] Preserving student offline examination data: %TARGET_DIR%\SecureStorage
) else (
    if exist "%TARGET_DIR%" (
        rmdir /Q "%TARGET_DIR%" >nul 2>&1
    )
)

echo ================================================================
echo [OK] Uninstallation complete.
echo Protocol registration and shortcuts removed.
echo ================================================================
exit /b 0
