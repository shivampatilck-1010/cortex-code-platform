@echo off
setlocal enabledelayedexpansion
echo ================================================================
echo CORTEX LOCKDOWN - DESKTOP CLIENT INSTALLER
echo Target: Windows 10/11 x64 Institutional Baseline
echo ================================================================

set "TARGET_DIR=%LOCALAPPDATA%\CortexLockdown"
set "SOURCE_EXE="

:: Locate source executable
if exist "%~dp0CortexLockdown.exe" (
    set "SOURCE_EXE=%~dp0CortexLockdown.exe"
) else if exist "%~dp0CortexLockdown-Hardened.exe" (
    set "SOURCE_EXE=%~dp0CortexLockdown-Hardened.exe"
) else if exist "%~dp0..\bin\CortexLockdown-Hardened.exe" (
    set "SOURCE_EXE=%~dp0..\bin\CortexLockdown-Hardened.exe"
) else if exist "%~dp0..\bin\CortexLockdown.exe" (
    set "SOURCE_EXE=%~dp0..\bin\CortexLockdown.exe"
)

if "%SOURCE_EXE%"=="" (
    echo [ERROR] CortexLockdown executable not found in "%~dp0" or "%~dp0..\bin\"
    exit /b 1
)

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: Prevent silently overwriting a newer installation
if exist "%TARGET_DIR%\CortexLockdown.exe" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$src='%SOURCE_EXE%'; $dst='%TARGET_DIR%\CortexLockdown.exe'; $srcV=[System.Diagnostics.FileVersionInfo]::GetVersionInfo($src).FileVersion; $dstV=[System.Diagnostics.FileVersionInfo]::GetVersionInfo($dst).FileVersion; if ($dstV -and $srcV) { try { if ([System.Version]$dstV -gt [System.Version]$srcV) { Write-Host ('[INFO] Existing installation is newer (Installed: ' + $dstV + ', Source: ' + $srcV + '). Skipping file copy.'); exit 2 } } catch {} }"
    if errorlevel 2 (
        echo [INFO] Existing newer binary preserved.
        goto :register_protocol
    )
)

echo [INFO] Copying application binary to %TARGET_DIR%\CortexLockdown.exe...
copy /Y "%SOURCE_EXE%" "%TARGET_DIR%\CortexLockdown.exe" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy executable to %TARGET_DIR%\CortexLockdown.exe
    exit /b 1
)

:register_protocol
echo [INFO] Registering custom protocol: cortex-lockdown://
reg add "HKCU\Software\Classes\cortex-lockdown" /ve /t REG_SZ /d "URL:Cortex Lockdown Secure Protocol" /f >nul
reg add "HKCU\Software\Classes\cortex-lockdown" /v "URL Protocol" /t REG_SZ /d "" /f >nul
reg add "HKCU\Software\Classes\cortex-lockdown\DefaultIcon" /ve /t REG_SZ /d "\"%TARGET_DIR%\CortexLockdown.exe\",0" /f >nul
reg add "HKCU\Software\Classes\cortex-lockdown\shell\open\command" /ve /t REG_SZ /d "\"%TARGET_DIR%\CortexLockdown.exe\" \"%%1\"" /f >nul

echo [INFO] Creating Start Menu shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut(\"$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Cortex Lockdown.lnk\"); $s.TargetPath = \"$env:LOCALAPPDATA\CortexLockdown\CortexLockdown.exe\"; $s.Save()" >nul 2>&1

echo ================================================================
echo [OK] Installation and protocol registration complete.
echo Executable: %TARGET_DIR%\CortexLockdown.exe
echo Web launcher link: cortex-lockdown://launch
echo ================================================================
exit /b 0
