﻿CORTEX LOCKDOWN - SECURE DESKTOP EXAMINATION CLIENT
Version: 1.0.0-hardened
Target: Windows 10/11 x64 Institutional Baseline
Payload SHA-256: 82518B2D6966E3FB358892A040F148E52AA5ECDF8CAB92E0D93A2A22F3AFC895

QUICK INSTALLATION:
1. Double-click install.bat to register the cortex-lockdown:// protocol and create Start Menu shortcuts.
2. Launch examinations directly from the Cortex classroom web portal.
3. To uninstall, run uninstall.bat.

SECURITY SPECIFICATIONS:
* OS Kiosk Mode with Low-Level Keyboard Hooks (WH_KEYBOARD_LL)
* Screen Capture Blocker (WDA_MONITOR)
* 21-Process Prohibited Watchdog (Task Manager, Snipping Tool, OBS, Discord, Wireshark, etc.)
* Zero-Tolerance Remote Session & Virtualization Detection
* Automated Real-Time Telemetry to Cortex Proctoring Feed
* Assembly Metadata and Windows Manifest for Antivirus Compatibility
* AES-256-GCM Encrypted Local Answer Persistence with PBKDF2 (100k)
